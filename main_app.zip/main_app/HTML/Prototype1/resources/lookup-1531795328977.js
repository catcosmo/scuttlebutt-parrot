(function(window, undefined) {
  var dictionary = {
    "f5a8e2cf-0a07-46b8-9333-1dd384004f6e": "2_search_Channel & Channel View",
    "0c8d88b0-1960-4dd5-9c92-9b984e2a22e3": "2_2_main_menue",
    "3f2b5dee-d7af-4df1-a530-0c07343e8c71": "feminism",
    "fde16259-8126-4ee3-9c2f-daac683ef30b": "connected",
    "843921ed-d804-4265-9407-da99b605cc31": "2_search_Channel & Channel View_with_message",
    "c40c60ae-9767-4024-80d0-ade8d1f45f88": "2_2_search_Channel & Channel View",
    "09692983-7dbb-4b89-b8fd-e58fae4ba00b": "Searching",
    "c7db6a83-18f4-41b3-b725-54d5d39f3113": "test",
    "0584d39a-e09e-4b1b-aff9-741d5bf470a0": "2_1_search_Channel & Channel View",
    "5fb4b527-d26b-476f-ba98-d3329274b4ad": "logo_info",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "1_connecting_to_network",
    "56876e82-837b-417e-ac74-e374e77e201f": "no_local_connection_found",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);